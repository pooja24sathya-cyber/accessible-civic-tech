# Technical Design Document

## 1. Purpose

The Rural Citizen Assistant aims to reduce information barriers faced by rural residents, older adults, and students who need help understanding government schemes, scholarship processes, and basic banking procedures.

## 2. Prototype architecture

```text
Citizen
  |
  v
Streamlit user interface
  |-- topic selection
  |-- question input
  |-- accessibility text toggle
  |
  v
Keyword-based retrieval
  |
  v
Local JSON knowledge base
  |
  v
Step-by-step answer + document checklist + official source link
```

## 3. Technology stack

- Python for application logic
- Streamlit for the web interface
- JSON for sample guidance entries
- pytest-compatible unit test for retrieval behavior

## 4. Data model

Each knowledge-base entry contains an ID, title, category, summary, keywords, steps, document checklist, and official URL. The sample content is illustrative and should be verified against current official sources.

## 5. Accessibility considerations

- Plain language and short steps
- Larger-text toggle
- Clear topic filters and quick topic examples
- Avoidance of unnecessary technical terms
- Safety reminder not to share secret banking credentials

## 6. Privacy and safety

The prototype does not need account credentials and should not request OTPs, PINs, passwords, or full bank details. Do not upload real applicants' personal documents into a public repository. Future versions should minimize data collection, obtain consent for microphone use, and explain how voice data is processed.

## 7. Limitations

- Retrieval is keyword-based, not a generative AI model.
- The sample content is English-only.
- Voice input and speech output are not implemented in this version.
- The prototype does not submit applications or determine eligibility.
- Official scheme requirements may change and must be checked before use.

## 8. Future work

- Verified regional-language content
- Speech input/output with explicit consent
- Retrieval-augmented generation using approved sources
- Source freshness and update monitoring
- User testing with target communities
- Accessibility, security, and privacy evaluation

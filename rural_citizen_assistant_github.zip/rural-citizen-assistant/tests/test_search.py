import json
from pathlib import Path

def search_entries(query, entries):
    query_words = set(query.lower().strip().split())
    scored = []
    for entry in entries:
        haystack = " ".join([
            entry.get("title", ""),
            entry.get("category", ""),
            entry.get("summary", ""),
            " ".join(entry.get("keywords", [])),
        ]).lower()
        score = sum(1 for word in query_words if len(word) > 2 and word in haystack)
        if score:
            scored.append((score, entry))
    scored.sort(key=lambda item: item[0], reverse=True)
    return [entry for _, entry in scored]

def load_entries():
    path = Path(__file__).parents[1] / "data" / "knowledge_base.json"
    return json.loads(path.read_text(encoding="utf-8"))["entries"]

def test_scholarship_search_returns_education_entry():
    results = search_entries("student scholarship documents", load_entries())
    assert results
    assert any("scholarship" in item["title"].lower() for item in results)

def test_unrelated_query_returns_no_results():
    results = search_entries("spaceship volcano", load_entries())
    assert results == []

import json
from pathlib import Path

import streamlit as st

BASE_DIR = Path(__file__).parent
DATA_PATH = BASE_DIR / "data" / "knowledge_base.json"

st.set_page_config(
    page_title="Rural Citizen Assistant",
    page_icon="🌾",
    layout="centered",
    initial_sidebar_state="expanded",
)

@st.cache_data
def load_knowledge_base():
    with DATA_PATH.open("r", encoding="utf-8") as file:
        return json.load(file)

def simplify_text(text: str) -> str:
    """Return a safe, readable response from the local sample knowledge base."""
    return " ".join(text.split())

def search_entries(query, entries):
    query_words = set(query.lower().strip().split())
    scored = []
    for entry in entries:
        haystack = " ".join([
            entry.get("title", ""),
            entry.get("category", ""),
            entry.get("summary", ""),
            " ".join(entry.get("keywords", [])),
        ]).lower()
        score = sum(1 for word in query_words if len(word) > 2 and word in haystack)
        if score:
            scored.append((score, entry))
    scored.sort(key=lambda item: item[0], reverse=True)
    return [entry for _, entry in scored]

def main():
    st.title("🌾 Rural Citizen Assistant")
    st.subheader("Simple guidance for government schemes and banking")
    st.write(
        "Understand common procedures through clear steps. This prototype uses "
        "sample information; confirm current rules with the official department or bank."
    )

    knowledge = load_knowledge_base()
    entries = knowledge.get("entries", [])

    with st.sidebar:
        st.header("Accessibility")
        large_text = st.toggle("Use larger text", value=True)
        st.caption("Tip: use the browser zoom controls if you need even larger text.")
        st.divider()
        st.markdown("**Safety reminder**")
        st.write("Never share your OTP, PIN, password, or full banking credentials.")

    if large_text:
        st.markdown(
            """
            <style>
            html, body, [class*="st-"] { font-size: 1.08rem; }
            .stButton button, .stSelectbox, .stTextInput { min-height: 3rem; }
            </style>
            """,
            unsafe_allow_html=True,
        )

    language = st.selectbox(
        "Preferred language",
        ["English", "தமிழ் (Tamil)", "हिन्दी (Hindi)"],
        help="The current prototype's sample knowledge base is in English. "
             "Regional-language content can be added and verified before release.",
    )

    category = st.selectbox(
        "What do you need help with?",
        ["All topics", "Government schemes", "Banking", "Education"],
    )

    question = st.text_input(
        "Type your question",
        placeholder="Example: What documents should I prepare for a student scholarship?",
    )

    if st.button("Find guidance", type="primary", use_container_width=True):
        if not question.strip():
            st.warning("Please type a question first.")
        else:
            results = search_entries(question, entries)
            if category != "All topics":
                category_map = {
                    "Government schemes": "government",
                    "Banking": "banking",
                    "Education": "education",
                }
                results = [
                    entry for entry in results
                    if entry.get("category", "").lower() == category_map[category]
                ]

            if not results:
                st.info(
                    "No close match was found in this sample guide. Try words such as "
                    "'scholarship', 'bank account', 'pension', or 'documents'."
                )
            else:
                for entry in results[:3]:
                    with st.container(border=True):
                        st.markdown(f"### {entry['title']}")
                        st.write(simplify_text(entry["summary"]))
                        st.markdown("**Steps to follow**")
                        for index, step in enumerate(entry.get("steps", []), start=1):
                            st.write(f"{index}. {step}")
                        st.markdown("**Documents to check**")
                        for document in entry.get("documents", []):
                            st.write(f"- {document}")
                        if entry.get("official_url"):
                            st.link_button(
                                "Check official source",
                                entry["official_url"],
                                use_container_width=True,
                            )
                        st.caption(
                            "Requirements may vary. Verify eligibility, deadlines, fees, "
                            "and document lists with the official authority."
                        )

    st.divider()
    st.subheader("Quick topics")
    cols = st.columns(2)
    quick_topics = [
        ("Student scholarship", "student scholarship documents"),
        ("Bank account", "documents for opening a bank account"),
        ("Pension guidance", "pension scheme eligibility"),
        ("Digital safety", "how to stay safe from banking fraud"),
    ]
    for i, (label, query) in enumerate(quick_topics):
        with cols[i % 2]:
            if st.button(label, use_container_width=True, key=f"quick_{i}"):
                st.session_state["quick_query"] = query
                st.info(f"Search for: {query}. Enter this phrase in the question box.")

    st.caption(
        "Educational prototype only. It does not submit applications, make eligibility "
        "decisions, or provide official legal or financial advice."
    )

if __name__ == "__main__":
    main()

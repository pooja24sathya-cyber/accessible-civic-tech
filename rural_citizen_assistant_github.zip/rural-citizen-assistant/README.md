# AI-Powered Rural Government & Banking Assistant

A Python/Streamlit prototype that helps rural citizens, elders, and students understand common government-scheme, education, and banking procedures in simpler steps.

## Features

- Searchable sample knowledge base
- Topic filters for government schemes, banking, and education
- Step-by-step instructions and document checklists
- Large-text accessibility toggle
- Official-source links for further verification
- Basic banking-fraud safety guidance

## Important scope note

This is a prototype, not an official government service and not a fully AI-powered or fully translated assistant yet. The current content is a small English sample knowledge base. Requirements and official URLs must be verified before real-world use. Do not collect Aadhaar numbers, OTPs, PINs, passwords, bank credentials, or other sensitive personal information in this demo.

## Run locally

1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

5. Start the app:

   ```bash
   streamlit run app.py
   ```

6. Open the local URL shown in the terminal.

## Repository structure

```text
rural-citizen-assistant/
├── app.py
├── requirements.txt
├── README.md
├── data/
│   └── knowledge_base.json
├── docs/
│   └── TECHNICAL_DESIGN.md
└── tests/
    └── test_search.py
```

## Suggested future improvements

- Add verified Tamil and Hindi content reviewed by fluent speakers.
- Integrate speech-to-text and text-to-speech with explicit language selection.
- Connect a grounded AI model that answers only from verified, versioned sources.
- Add source dates, scheme update checks, and clear uncertainty messages.
- Conduct usability testing with older adults and low-digital-literacy users.
- Add automated tests, privacy review, and accessibility testing.

## Disclaimer

The information in this educational prototype is general guidance. Scheme eligibility, document lists, fees, and deadlines can change and may vary by state, bank, or scheme. Confirm details with the relevant official department or bank before acting.
